package com.lyricsbridge.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Dibuja la letra "en el aire": un letrero que flota en el mundo frente a ti, mirando siempre
 * a la cámara. Se queda quieto en el mundo y solo se reacomoda (con un deslizamiento suave)
 * cuando te das la vuelta o te alejas.
 *
 * Opciones por argumento JVM:
 *   -Dlyricsbridge.distance=5   (bloques frente a ti)
 *   -Dlyricsbridge.height=0.5   (bloques sobre tus ojos)
 *   -Dlyricsbridge.scale=0.05   (tamaño del texto)
 */
final class WorldLyrics {
    private static final double DIST = prop("lyricsbridge.distance", 5.0);
    private static final double HEIGHT = prop("lyricsbridge.height", 0.5);
    private static final float SCALE = (float) prop("lyricsbridge.scale", 0.05);
    private static final double COS_LIMIT = Math.cos(Math.toRadians(55)); // ángulo máximo antes de reacomodar
    private static final int FULL_BRIGHT = 0xF000F0;

    private static double ax, ay, az;
    private static boolean have;
    private static boolean gliding;
    private static long lastNs;

    private WorldLyrics() {}

    private static double prop(String key, double def) {
        try {
            return Double.parseDouble(System.getProperty(key, Double.toString(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Olvida la posición; la próxima letra aparecerá justo frente a ti. */
    static void reset() {
        have = false;
        gliding = false;
    }

    static void render(LevelRenderContext ctx, String prev, String line, String next) {
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        CameraRenderState cam = ctx.levelState().cameraRenderState;
        Vec3 cp = cam.pos;
        Quaternionf rot = cam.orientation;

        long nowNs = System.nanoTime();
        double dt = Math.min(0.1, Math.max(0.0, (nowNs - lastNs) / 1.0e9));
        lastNs = nowNs;

        // Dirección horizontal hacia donde miras
        Vector3f fwd = rot.transform(new Vector3f(0f, 0f, -1f));
        double hl = Math.hypot(fwd.x, fwd.z);
        boolean looksHorizontal = hl > 1.0e-3;
        double dx = looksHorizontal ? fwd.x / hl : 0.0;
        double dz = looksHorizontal ? fwd.z / hl : 0.0;

        double tx = cp.x + dx * DIST;
        double ty = cp.y + HEIGHT;
        double tz = cp.z + dz * DIST;

        if (!have) {
            ax = tx; ay = ty; az = tz;
            have = true;
            gliding = false;
        } else {
            double vx = ax - cp.x;
            double vz = az - cp.z;
            double vl = Math.hypot(vx, vz);
            double cos = (looksHorizontal && vl > 1.0e-3) ? (vx * dx + vz * dz) / vl : 1.0;
            if (vl > DIST * 2.5 || vl < 1.5 || cos < COS_LIMIT) gliding = true;
            if (gliding) {
                double k = 1.0 - Math.exp(-5.0 * dt);
                ax += (tx - ax) * k;
                ay += (ty - ay) * k;
                az += (tz - az) * k;
                if (Math.abs(tx - ax) + Math.abs(ty - ay) + Math.abs(tz - az) < 0.05) gliding = false;
            }
        }

        // Coordenadas relativas a la cámara + giro para mirar siempre hacia ella (como las etiquetas de nombre)
        PoseStack ps = new PoseStack();
        ps.translate(ax - cp.x, ay - cp.y, az - cp.z);
        ps.mulPose(new Matrix4f().rotation(rot));
        ps.scale(SCALE, -SCALE, SCALE);

        centered(ctx, ps, font, prev, -14f, 0x99FFFFFF);
        centered(ctx, ps, font, line, 0f, 0xFFFFFF55);
        centered(ctx, ps, font, next, 14f, 0x99FFFFFF);
    }

    private static void centered(LevelRenderContext ctx, PoseStack ps, Font font, String text, float y, int argb) {
        if (text == null || text.isEmpty()) return;
        FormattedCharSequence seq = Component.literal(text).getVisualOrderText();
        float x = -font.width(seq) / 2f;
        ctx.submitNodeCollector().submitText(ps, x, y, seq, true, Font.DisplayMode.NORMAL, FULL_BRIGHT, argb, 0, 0);
    }
}
